import React, { useState } from "react";
import "./Soal9.css";
export default function Soal9() {
  // State untuk menyimpan input pengguna dan hasil output
  const [childrenNames, setChildrenNames] = useState("");
  const [result, setResult] = useState("");

  // Fungsi untuk mendapatkan anak nakal
  const getNaughtyChildren = () => {
    try {
      // Parsing input string menjadi array nama anak
      const namesArray = JSON.parse(childrenNames);
      if (!Array.isArray(namesArray)) {
        throw new Error("Input harus berupa array nama anak.");
      }

      // Menghitung frekuensi setiap nama anak
      const frequencyMap = {};
      for (const name of namesArray) {
        frequencyMap[name] = (frequencyMap[name] || 0) + 1;
      }

      // Menemukan anak nakal (disebut lebih dari satu kali)
      const naughtyChildren = Object.keys(frequencyMap).filter(
        (name) => frequencyMap[name] > 1
      );

      // Jika ada anak nakal, tampilkan nama-namanya
      if (naughtyChildren.length > 0) {
        setResult(`Anak Nakal: ${naughtyChildren.join(", ")}`);
      } else {
        setResult("Semuanya anak baik");
      }
    } catch (error) {
      alert(error.message); // Menampilkan pesan error jika input tidak valid
      setResult("");
    }
  };

  return (
    <div className="container-9">
      <h1 className="title-9">Pencatatan Anak Nakal</h1>
      <form className="form-9">
        <textarea
          className="input-9"
          placeholder='Masukkan daftar nama anak (contoh: ["Bagas", "Dimas", "Fajar"])'
          value={childrenNames}
          onChange={(e) => setChildrenNames(e.target.value)}
        />
        <button
          type="button"
          className="check-button-9"
          onClick={getNaughtyChildren}
        >
          Check Naughty Children
        </button>
      </form>
      {result && (
        <div className="output-9">
          <p>{result}</p>
        </div>
      )}
    </div>
  );
}
