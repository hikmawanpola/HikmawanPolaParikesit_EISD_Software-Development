import { useState } from "react";
import "./Soal1.css";

export default function Soal1() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);

  const calculateRatings = () => {
    const ratings = input
      .split(",")
      .map((num) => parseFloat(num.trim()))
      .filter((num) => !isNaN(num));

    if (ratings.length === 0) {
      setResult("Masukkan angka yang valid!");
      return;
    }

    const min = Math.min(...ratings);
    const max = Math.max(...ratings);
    const avg =
      ratings.reduce((total, current) => total + current, 0) / ratings.length;

    setResult([min, max, parseFloat(avg.toFixed(2))]);
  };

  return (
    <div className="body-1">
      <div className="container-1">
        <h2 className="h2-1">🚀 Hitung Rating 🚀</h2>
        <input
          className="input-1"
          type="text"
          placeholder="Masukkan rating (contoh: 4.5, 2.0, 1.5)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button className="button-1" onClick={calculateRatings}>
          🔥 Hitung Sekarang 🔥
        </button>
        {result && (
          <div className="result-1">Hasil: {JSON.stringify(result)}</div>
        )}
      </div>
    </div>
  );
}
