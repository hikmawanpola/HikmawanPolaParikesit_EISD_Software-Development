import React, { useState } from "react";
import "./Soal7.css";
export default function Soal7() {
  // State untuk menyimpan input pengguna dan hasil dekripsi
  const [encryptedText, setEncryptedText] = useState("");
  const [decryptedText, setDecryptedText] = useState("");

  // Fungsi untuk dekripsi
  const decryptMessage = (text) => {
    let result = "";
    for (let char of text) {
      if (char.match(/[a-z]/i)) {
        // Mengonversi huruf menjadi kode ASCII
        let code = char.charCodeAt(0);
        let base =
          char === char.toLowerCase() ? "a".charCodeAt(0) : "A".charCodeAt(0);
        // Geser mundur 5 posisi dalam alfabet
        let shiftedCode = ((code - base - 5 + 26) % 26) + base;
        result += String.fromCharCode(shiftedCode);
      } else {
        // Tambahkan karakter non-huruf tanpa perubahan
        result += char;
      }
    }
    return result;
  };

  // Fungsi yang dipanggil saat tombol "Decrypt" ditekan
  const handleDecrypt = () => {
    const decrypted = decryptMessage(encryptedText);
    setDecryptedText(decrypted);
  };

  return (
    <div className="container-7">
      <h1 className="title-7">Dekripsi Chat Terenkripsi</h1>
      <form className="form-7">
        <textarea
          className="input-7"
          placeholder='Masukkan teks terenkripsi (contoh: "xfqfr bfmdz")'
          value={encryptedText}
          onChange={(e) => setEncryptedText(e.target.value)}
        />
        <button
          type="button"
          className="decrypt-button-7"
          onClick={handleDecrypt}
        >
          Decrypt
        </button>
      </form>
      {decryptedText && (
        <div className="output-7">
          <p>
            Teks Dekripsi: <strong>{decryptedText}</strong>
          </p>
        </div>
      )}
    </div>
  );
}
