import { useState } from "react";
import "./Soal2.css";

export default function Soal2() {
  const [inputText, setInputText] = useState("");
  const [result, setResult] = useState("");

  const checkWords = (text) => {
    if (!text.trim()) return "Masukkan input yang valid"; // Cek jika input kosong

    const words = text.split(" "); // Pisahkan kata-kata dalam kalimat
    for (let word of words) {
      if (word.length > 1) {
        const firstChar = word[0];
        const lastChar = word[word.length - 1];

        // Cek apakah huruf depan dan belakang sama (baik kapital maupun lowercase)
        if (
          (firstChar === lastChar && firstChar === firstChar.toUpperCase()) ||
          (firstChar === lastChar && firstChar === firstChar.toLowerCase())
        ) {
          return "eureeka!";
        }
      }
    }
    return "suka blyat";
  };

  const checkPalindrome = () => {
    setResult(checkWords(inputText));
  };

  return (
    <div className="container-2">
      <h2 className="h2-2">Palindrom setiap kata</h2>
      <input
        className="input-2"
        type="text"
        placeholder="Masukkan kata atau kalimat"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
      />
      <button className="button-2" onClick={checkPalindrome}>
        Cek
      </button>
      {result && <p className="result-2">{result}</p>}
    </div>
  );
}
