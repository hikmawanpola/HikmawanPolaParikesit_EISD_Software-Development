import React, { useState } from "react";
import "./Soal4.css";
export default function Soal4() {
  const [inputArray, setInputArray] = useState("");
  const [hasDuplicate, setHasDuplicate] = useState(null);
  const [error, setError] = useState("");

  const checkForDuplicates = (array) => {
    // More efficient duplicate check using Set size comparison
    return new Set(array).size !== array.length;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (!inputArray.trim()) {
      setError("Input tidak boleh kosong");
      setHasDuplicate(null);
      return;
    }

    try {
      const parsedArray = JSON.parse(inputArray);

      if (!Array.isArray(parsedArray)) {
        throw new Error("Input harus berupa array (contoh: [1, 2, 3])");
      }

      if (parsedArray.some((item) => typeof item !== "number")) {
        throw new Error("Array hanya boleh berisi angka");
      }

      const result = checkForDuplicates(parsedArray);
      setHasDuplicate(result);
    } catch (error) {
      setError(error.message);
      setHasDuplicate(null);
    }
  };

  const handleReset = () => {
    setInputArray("");
    setHasDuplicate(null);
    setError("");
  };

  return (
    <div className="duplicate-checker-4">
      <div className="card-4">
        <h2 className="title-4">Pemeriksa Duplikat Array</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group-4">
            <label htmlFor="array-input">
              Masukkan array angka (contoh: [1, 2, 3, 4])
            </label>
            <textarea
              id="array-input"
              className={`input-4
                 ${error ? "error" : ""}`}
              value={inputArray}
              onChange={(e) => setInputArray(e.target.value)}
              rows={4}
            />
            {error && <p className="error-message-4">{error}</p>}
          </div>

          <div className="button-group-4">
            <button type="submit" className="check-button-4">
              Periksa Duplikat
            </button>
            <button
              type="button"
              className="reset-button-4"
              onClick={handleReset}
            >
              Reset
            </button>
          </div>
        </form>

        {hasDuplicate !== null && (
          <div
            className={`result-4 ${
              hasDuplicate ? "has-duplicate-4" : "no-duplicate-4"
            }`}
          >
            <p>
              Hasil pemeriksaan:{" "}
              <strong>{hasDuplicate ? "ADA" : "TIDAK ADA"} duplikat</strong>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
