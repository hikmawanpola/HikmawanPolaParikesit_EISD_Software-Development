import React, { useState } from "react";
import "./Soal8.css";
export default function Soal8() {
  // Data produk
  const products = [
    { nama: "TV", kategori: "elektronik", harga: 1000 },
    { nama: "headphone", kategori: "elektronik", harga: 200 },
    { nama: "baju", kategori: "fashion", harga: 50 },
    { nama: "gitar", kategori: "musik", harga: 300 },
    { nama: "sepatu", kategori: "olahraga", harga: 80 },
    { nama: "kamera", kategori: "elektronik", harga: 600 },
  ];

  // Data pelanggan
  const customers = [
    { nama: "Rina", minat: ["elektronik", "musik"], beli: ["TV", "headphone"] },
    { nama: "Budi", minat: ["fashion", "musik"], beli: ["baju", "gitar"] },
    {
      nama: "Hartono",
      minat: ["olahraga", "elektronik"],
      beli: ["sepatu", "kamera"],
    },
  ];

  // State untuk menyimpan input pengguna dan hasil rekomendasi
  const [customerName, setCustomerName] = useState("");
  const [recommendations, setRecommendations] = useState([]);

  // Fungsi untuk mendapatkan rekomendasi produk
  const getRecommendations = () => {
    // Temukan pelanggan berdasarkan nama
    const customer = customers.find((c) => c.nama === customerName);
    if (!customer) {
      alert("Pelanggan tidak ditemukan.");
      return;
    }

    // Produk yang sesuai dengan kategori minat pelanggan
    const recommendedProducts = products
      .filter((product) => customer.minat.includes(product.kategori))
      .map((p) => p.nama); // Ambil hanya nama produk

    // Gabungkan produk yang sudah dibeli dan rekomendasi baru
    const finalRecommendations = [
      ...new Set([...customer.beli, ...recommendedProducts]),
    ];

    // Simpan hasil rekomendasi
    setRecommendations(finalRecommendations);
  };

  return (
    <div className="container-8">
      <h1 className="title-8">Rekomendasi Produk Toko Online</h1>
      <form className="form-8">
        <input
          type="text"
          className="input-8"
          placeholder='Masukkan nama pelanggan (contoh: "Rina")'
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
        />
        <button
          type="button"
          className="recommend-button-8"
          onClick={getRecommendations}
        >
          Get Recommendations
        </button>
      </form>
      {recommendations.length > 0 && (
        <table border="1" className="output-8">
          <thead>
            <tr>
              <th>
                <strong>Input</strong>
              </th>
              <th>
                <strong>Output</strong>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{customerName}</td>
              <td>
                [
                {recommendations.map((item, index) => (
                  <span key={index}>
                    {index > 0 && ", "} "{item}"
                  </span>
                ))}
                ]
              </td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
}
