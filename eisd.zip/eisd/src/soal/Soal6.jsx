import React from "react";
import "./Soal6.css";
export default function Soal6() {
  // Data menu restoran
  const menu = [
    { nama: "Ayam Goreng Krispi", tipe: "Makanan", harga: 15000 },
    { nama: "Ayam Puk Puk (Bukan di geprek)", tipe: "Makanan", harga: 13000 },
    { nama: "Ayam Bakar", tipe: "Makanan", harga: 20000 },
    { nama: "Es teh", tipe: "Minuman", harga: 5000 },
    { nama: "Es Jeruk", tipe: "Minuman", harga: 7000 },
  ];

  // Pesanan pelanggan
  const pesanan = [
    {
      nama: "Rehan Whangsap",
      items: [
        { nama: "Ayam Bakar", jumlah: 2 },
        { nama: "Es teh", jumlah: 1 },
      ],
    },
    {
      nama: "Amba Roni",
      items: [
        { nama: "Ayam Puk Puk (Bukan di geprek)", jumlah: 1 },
        { nama: "Es teh", jumlah: 3 },
      ],
    },
    {
      nama: "Faiz Ngawi",
      items: [
        { nama: "Ayam Goreng Krispi", jumlah: 1 },
        { nama: "Ayam Puk Puk (Bukan di geprek)", jumlah: 1 },
        { nama: "Ayam Bakar", jumlah: 1 },
        { nama: "Es teh", jumlah: 1 },
        { nama: "Es Jeruk", jumlah: 1 },
      ],
    },
  ];

  // Fungsi untuk menghitung pajak
  const hitungPajak = (harga, tipe) => {
    let pajakItem;
    if (tipe === "Makanan") {
      pajakItem = harga * 0.05; // 5% pajak makanan
    } else if (tipe === "Minuman") {
      pajakItem = harga * 0.03; // 3% pajak minuman
    }
    return pajakItem;
  };

  // Fungsi untuk menghitung total biaya pesanan
  const hitungTotalBiaya = (pesananPelanggan) => {
    let subtotal = 0;

    // Menghitung subtotal pesanan
    pesananPelanggan.items.forEach((item) => {
      const menuItem = menu.find((m) => m.nama === item.nama);
      if (menuItem) {
        subtotal += menuItem.harga * item.jumlah;
      }
    });

    // Menghitung pajak transaksi (15%)
    const pajakTransaksi = subtotal * 0.15;

    // Total biaya
    const totalBiaya = subtotal + pajakTransaksi;

    return {
      subtotal,
      pajakTransaksi,
      totalBiaya,
    };
  };

  return (
    <div className="container-6">
      <h1 className="title-6">Menu Restoran Jomok Fried Chicken</h1>
      <table className="menu-table-6">
        <thead>
          <tr>
            <th>Menu</th>
            <th>Tipe</th>
            <th>Harga</th>
          </tr>
        </thead>
        <tbody>
          {menu.map((item, index) => (
            <tr key={index}>
              <td>{item.nama}</td>
              <td>{item.tipe}</td>
              <td>Rp {item.harga.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 className="subtitle-6">Pesanan Pelanggan</h2>
      <div className="customer-orders-6">
        {pesanan.map((pelanggan, index) => {
          const { subtotal, pajakTransaksi, totalBiaya } =
            hitungTotalBiaya(pelanggan);
          return (
            <div key={index} className="customer-order-6">
              <h3>{pelanggan.nama}</h3>
              <ul>
                {pelanggan.items.map((item, idx) => (
                  <li key={idx}>
                    {item.jumlah} x {item.nama}
                  </li>
                ))}
              </ul>
              <p>Subtotal: Rp {subtotal.toLocaleString()}</p>
              <p>Pajak Transaksi: Rp {pajakTransaksi.toLocaleString()}</p>
              <p>Total Biaya: Rp {totalBiaya.toLocaleString()}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
