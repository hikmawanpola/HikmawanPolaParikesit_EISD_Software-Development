import React, { useState } from "react";
import "./Soal10.css";
export default function Soal10() {
  // State untuk menyimpan input pengguna dan hasil kembalian
  const [totalPembayaran, setTotalPembayaran] = useState("");
  const [totalBelanja, setTotalBelanja] = useState("");
  const [changeResult, setChangeResult] = useState(null);

  // Fungsi untuk membersihkan input dari pemisah ribuan (titik atau koma)
  const cleanInput = (input) => {
    return input.replace(/[.,]/g, ""); // Menghapus titik atau koma
  };

  // Fungsi untuk menghitung kembalian
  const calculateChange = () => {
    try {
      // Membersihkan input dari pemisah ribuan
      const cleanedPembayaran = cleanInput(totalPembayaran);
      const cleanedBelanja = cleanInput(totalBelanja);

      // Parsing input menjadi angka
      const pembayaran = parseInt(cleanedPembayaran, 10);
      const belanja = parseInt(cleanedBelanja, 10);

      if (isNaN(pembayaran) || isNaN(belanja)) {
        throw new Error("Input harus berupa angka.");
      }

      // Menghitung kembalian
      let kembalian = pembayaran - belanja; // Ganti 'const' menjadi 'let'

      if (kembalian < 0) {
        throw new Error(
          "Total pembayaran harus lebih besar atau sama dengan total belanja."
        );
      }

      // Pecahan uang yang tersedia
      const denominations = [
        100000, 50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100,
      ];
      const changeMap = {};

      // Menggunakan algoritma greedy untuk membagi kembalian
      for (const denomination of denominations) {
        const count = Math.floor(kembalian / denomination);
        if (count > 0) {
          changeMap[denomination] = count;
          kembalian -= count * denomination; // Mengubah nilai kembalian
        }
      }

      // Menampilkan hasil
      setChangeResult(changeMap);
    } catch (error) {
      alert(error.message); // Menampilkan pesan error jika input tidak valid
      setChangeResult(null);
    }
  };

  return (
    <div className="container-10">
      <h1 className="title-10">Penghitung Kembalian Uang Tunai</h1>
      <form className="form-10">
        <label htmlFor="totalPembayaran" className="label-10">
          Total Pembayaran:
        </label>
        <input
          type="text"
          id="totalPembayaran"
          className="input-10"
          placeholder="Masukkan total pembayaran"
          value={totalPembayaran}
          onChange={(e) => setTotalPembayaran(e.target.value)}
        />

        <label htmlFor="totalBelanja" className="label-10">
          Total Belanja:
        </label>
        <input
          type="text"
          id="totalBelanja"
          className="input-10"
          placeholder="Masukkan total belanja"
          value={totalBelanja}
          onChange={(e) => setTotalBelanja(e.target.value)}
        />

        <button
          type="button"
          className="calculate-button-10"
          onClick={calculateChange}
        >
          Hitung Kembalian
        </button>
      </form>
      {changeResult && (
        <div className="output-10">
          <p>
            Kembalian: <strong>{JSON.stringify(changeResult)}</strong>
          </p>
        </div>
      )}
    </div>
  );
}
