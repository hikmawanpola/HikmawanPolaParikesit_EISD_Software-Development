import React, { useState, useEffect } from "react";
import "./Soal5.css";

export default function Soal5() {
  const [usernameCount, setUsernameCount] = useState(0);
  const [sampleUsernames, setSampleUsernames] = useState([]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [animationActive, setAnimationActive] = useState(false);

  const fullName = "naiplovyu"; // Combined and lowercase as per requirements
  const maxLength = 6;

  // Calculate all possible username combinations
  const calculateUsernames = () => {
    setIsCalculating(true);
    setAnimationActive(true);

    // This is a simplified calculation for demonstration
    // The actual combinatorial calculation would be more complex
    const count = Math.pow(fullName.length, maxLength);
    const samples = [];

    // Generate some sample usernames
    for (let i = 0; i < 5; i++) {
      let sample = "";
      for (let j = 0; j < maxLength; j++) {
        sample += fullName.charAt(Math.floor(Math.random() * fullName.length));
      }
      samples.push(sample);
    }

    setTimeout(() => {
      setUsernameCount(count.toLocaleString());
      setSampleUsernames(samples);
      setIsCalculating(false);
      setTimeout(() => setAnimationActive(false), 1000);
    }, 1500);
  };

  useEffect(() => {
    calculateUsernames();
  }, []);

  return (
    <div className="neon-purple-container-5">
      <div className="neon-card-5">
        <h2 className="neon-title-5">Instagram Username Generator</h2>
        <div className="neon-content-5">
          <div className="input-display-5">
            <span className="neon-label-5">Nama Lengkap:</span>
            <span className="neon-value-5">Naip Lovyu</span>
          </div>

          <div className="input-display-5">
            <span className="neon-label-5">Diolah menjadi:</span>
            <span className="neon-value-5">{fullName}</span>
          </div>

          <div className="input-display-5">
            <span className="neon-label-5">Panjang Maksimal:</span>
            <span className="neon-value-5">{maxLength} karakter</span>
          </div>

          <div
            className={`result-container-5 ${animationActive ? "pulse" : ""}`}
          >
            <div className="count-display-5">
              <span className="neon-label-5">Total Kombinasi:</span>
              <span className="neon-count-5">
                {isCalculating ? (
                  <span className="calculating-5">Menghitung...</span>
                ) : (
                  usernameCount
                )}
              </span>
            </div>

            {sampleUsernames.length > 0 && (
              <div className="sample-usernames-5">
                <span className="neon-label-5">Contoh Username:</span>
                <div className="username-list-5">
                  {sampleUsernames.map((username, index) => (
                    <span key={index} className="username-item-5">
                      @{username}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <button
          className={`neon-button-5 ${animationActive ? "active" : ""}`}
          onClick={calculateUsernames}
          disabled={isCalculating}
        >
          {isCalculating ? "Menghitung..." : "Hitung Ulang"}
        </button>
      </div>

      <div className="neon-footer-5">
        <p>Dibuat khusus untuk Naip yang alay</p>
      </div>
    </div>
  );
}
