import { useState } from "react";
import "./Soal3.css";

export default function Soal3() {
  const [result, setResult] = useState("");

  const guests = ["Ningguang", "Hutao", "Xiao", "Childe"];
  const habits = {
    Ningguang: "memeriksa kue sebelum memberikan kado.",
    Hutao: "langsung memberikan kado tanpa memperhatikan kue.",
    Xiao: "memotret apa pun yang ia lihat pertama kali di ruangan.",
    Childe:
      "selalu membawa air mineral dan meletakkannya di meja sebelum memberikan kado.",
  };

  const solveMystery = () => {
    const cakeExistsInPhoto = false;
    let culprit = "";

    if (!cakeExistsInPhoto) {
      culprit = guests[0]; // Ningguang masuk pertama, berarti dia paling dicurigai
    }

    setResult(
      culprit
        ? `Pelakunya kemungkinan besar adalah ${culprit}, karena dia masuk pertama kali dan setelah itu kue sudah tidak ada di foto. Kebiasaannya adalah: "${habits[culprit]}".`
        : "Tidak bisa menentukan pelaku dengan informasi yang ada."
    );
  };

  return (
    <div className="container-3">
      <h2 className="h2-3">Misteri Hilangnya Kue</h2>
      <p className="p-3">
        Abah Zhongli kehilangan kue ulang tahunnya! Bantu Yanfei untuk menemukan
        siapa yang mengambilnya.
      </p>

      {/* Menampilkan daftar kebiasaan setiap tamu */}
      <div className="habits-list">
        <h3>Kebiasaan Setiap Tamu:</h3>
        <ul>
          {Object.entries(habits).map(([name, habit]) => (
            <li key={name}>
              <strong>{name}:</strong> {habit}
            </li>
          ))}
        </ul>
      </div>

      <button className="button-3" onClick={solveMystery}>
        Cari Pelaku
      </button>
      {result && <p className="result-3">{result}</p>}
    </div>
  );
}
