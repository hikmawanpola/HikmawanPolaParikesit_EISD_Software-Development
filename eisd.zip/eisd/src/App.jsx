import { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useLocation,
} from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
// Avatar component
// Di luar Home, letakkan Avatar agar bisa digunakan di mana-mana
const Avatar = ({
  src = "/profil.jpg",
  alt = "Profile Picture",
  initials = "HP",
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="bio-avatar">
      {imgError ? (
        <span className="avatar-initials">{initials}</span>
      ) : (
        <img src={src} alt={alt} onError={() => setImgError(true)} />
      )}
    </div>
  );
};

import "./App.css";

// Import all Soal components
import Soal1 from "./soal/Soal1";
import Soal2 from "./soal/Soal2";
import Soal3 from "./soal/Soal3";
import Soal4 from "./soal/Soal4";
import Soal5 from "./soal/Soal5";
import Soal6 from "./soal/Soal6";
import Soal7 from "./soal/Soal7";
import Soal8 from "./soal/Soal8";
import Soal9 from "./soal/Soal9";
import Soal10 from "./soal/Soal10";

// Properly implemented Avatar component

// Home component with counter functionality
const Home = () => {
  // Sample bio data - replace with your own
  const bioData = {
    name: "Hikmawan Pola Parikesit",
    title: "Web Developer",
    description:
      "I'm a passionate web developer with expertise in React, JavaScript, and modern front-end technologies. Welcome to my portfolio and practice application!",
    skills: ["React", "JavaScript", "HTML/CSS", "Node.js", "UI/UX Design"],
    education: "Bachelor of Technology - Informatics",
    experience: "3+ years of web development experience",
    email: "hikmawan02pp@gmail.com",
    github: "https://github.com/hikmawanpola",
  };

  return (
    <div className="home-container">
      <div className="bio-background">
        <div className="bio-content">
          <div className="bio-header">
            <div className="bio-titles">
              <h1 className="bio-name">{bioData.name}</h1>
              <h2 className="bio-title">{bioData.title}</h2>
            </div>
          </div>

          {/* Fixed Avatar component usage */}
          <Avatar src="./profil.jpg" initials="HP" />
          <div className="bio-description">
            <p>{bioData.description}</p>
          </div>

          <div className="bio-details">
            <div className="bio-section">
              <h3 className="bio-section-title">Skills</h3>
              <div className="bio-skills">
                {bioData.skills.map((skill, index) => (
                  <span key={index} className="bio-skill-tag">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="bio-section">
              <h3 className="bio-section-title">Education</h3>
              <p>{bioData.education}</p>
            </div>
          </div>

          <div className="bio-contact">
            <h3 className="bio-section-title">Contact</h3>
            <div className="bio-contact-info">
              <div className="bio-contact-item">
                <span className="bio-contact-label">Email:</span>
                <span className="bio-contact-value">{bioData.email}</span>
              </div>
              <div className="bio-contact-item">
                <span className="bio-contact-label">GitHub:</span>
                <span className="bio-contact-value">{bioData.github}</span>
              </div>
            </div>
            <div className="bio-contact">
              <h3 className="bio-section-title">Experience</h3>
              <p>{bioData.experience}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Enhanced Sidebar Navigation component
const SidebarNavigation = () => {
  const location = useLocation();
  const [isHovered, setIsHovered] = useState(null);

  // Array of menu items with their paths and colors
  const menuItems = [
    { name: "Home", path: "/", color: "#4f46e5" },
    { name: "Soal 1", path: "/soal1", color: "#7c3aed" },
    { name: "Soal 2", path: "/soal2", color: "#2563eb" },
    { name: "Soal 3", path: "/soal3", color: "#0284c7" },
    { name: "Soal 4", path: "/soal4", color: "#0891b2" },
    { name: "Soal 5", path: "/soal5", color: "#0d9488" },
    { name: "Soal 6", path: "/soal6", color: "#059669" },
    { name: "Soal 7", path: "/soal7", color: "#16a34a" },
    { name: "Soal 8", path: "/soal8", color: "#ca8a04" },
    { name: "Soal 9", path: "/soal9", color: "#ea580c" },
    { name: "Soal 10", path: "/soal10", color: "#dc2626" },
  ];

  return (
    <div className="sidebar-navigation">
      <div className="sidebar-header">
        <div className="logo-container">
          <a
            href="https://vitejs.dev"
            target="_blank"
            rel="noopener noreferrer"
            className="logo-link"
          >
            <img src={viteLogo} className="logo" alt="Vite logo" />
          </a>
          <a
            href="https://react.dev"
            target="_blank"
            rel="noopener noreferrer"
            className="logo-link"
          >
            <img src={reactLogo} className="logo react" alt="React logo" />
          </a>
        </div>
        <h1 className="app-title">Vite + React</h1>
        <div className="sidebar-divider"></div>
      </div>
      <ul className="sidebar-menu">
        {menuItems.map((item, index) => {
          const isActive = location.pathname === item.path;

          return (
            <li
              key={index}
              className={`sidebar-menu-item ${isActive ? "active" : ""}`}
              onMouseEnter={() => setIsHovered(index)}
              onMouseLeave={() => setIsHovered(null)}
              style={{ "--index": index }}
            >
              <Link
                to={item.path}
                className="sidebar-link"
                style={{
                  background:
                    isActive || isHovered === index
                      ? `linear-gradient(90deg, ${item.color}33, ${item.color}66)`
                      : "transparent",
                  color: isActive
                    ? item.color
                    : isHovered === index
                    ? item.color
                    : "#a0aec0",
                  borderLeft: isActive
                    ? `4px solid ${item.color}`
                    : "4px solid transparent",
                }}
              >
                <div
                  className="sidebar-icon"
                  style={{ backgroundColor: item.color }}
                >
                  {index === 0 ? "🏠" : `${index}`}
                </div>
                <span className="sidebar-text">{item.name}</span>
                {isActive && (
                  <div
                    className="sidebar-active-indicator"
                    style={{ backgroundColor: item.color }}
                  ></div>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="sidebar-footer">
        <p>© {new Date().getFullYear()} - React App</p>
      </div>
    </div>
  );
};

// App component needs to be inside Router, but SidebarNavigation needs location
const AppContent = () => {
  return (
    <div className="app-layout">
      <SidebarNavigation />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/soal1" element={<Soal1 />} />
          <Route path="/soal2" element={<Soal2 />} />
          <Route path="/soal3" element={<Soal3 />} />
          <Route path="/soal4" element={<Soal4 />} />
          <Route path="/soal5" element={<Soal5 />} />
          <Route path="/soal6" element={<Soal6 />} />
          <Route path="/soal7" element={<Soal7 />} />
          <Route path="/soal8" element={<Soal8 />} />
          <Route path="/soal9" element={<Soal9 />} />
          <Route path="/soal10" element={<Soal10 />} />
        </Routes>
      </main>
    </div>
  );
};

// Main App component
const App = () => {
  return (
    <Router>
      <AppContent />
    </Router>
  );
};

export default App;
